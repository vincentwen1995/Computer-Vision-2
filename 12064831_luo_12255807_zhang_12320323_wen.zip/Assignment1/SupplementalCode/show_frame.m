function show_frame(frame,C)
fscatter3(frame(1,:)', frame(2,:)', frame(3,:)',C');
rotate3d on
end