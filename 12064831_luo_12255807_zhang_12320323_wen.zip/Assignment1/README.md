## Instructions
1. To run these code, you need to copy the dataset into this folder
2. Run ICP_experiments.m and conduct different kinds of experiments on the ICP algorithm
3. Run merging_scenes_1.m and merging_scenes_2.m to test merging scenes with two strategies
4. Run visualize.m to have a better view of the output of merging scenes
