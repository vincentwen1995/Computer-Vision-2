% 3.1 Merging Scenes
clear all;clc;close all;
addpath('SupplementalCode/');
rotation = eye(3, 3);
translation = zeros(3, 1);
target = load_pcd(0);
merged_frame = target;
merged_color = ones(1,size(target,2));
stepsize=1; % 2,4,10
for i = stepsize:stepsize:99
    fprintf("Iter:%d\n",i);
    % New frame as source
    source=load_pcd(i);
    [R, t] = ICP_uniform(source,target,1000);
    rotation = R * rotation;
    translation = bsxfun(@plus, R * translation, t);
    source_transformed=bsxfun(@plus, rotation * source, translation);
    merged_frame = [merged_frame source_transformed];
    merged_color = [merged_color ones(1,size(source_transformed,2))*(i+1)];
    % Old frame as target
    target = source;
end
save('merging_scenes_1.mat','merged_frame','merged_color')
show_frame(merged_frame,merged_color);
    
    
    
   